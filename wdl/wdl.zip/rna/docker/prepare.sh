git clone https://gitee.com/singleron-rd/celescope_tests.git
cp ./celescope/wdl/rna/docker/submit_de.sh .
cp ./celescope/wdl/rna/docker/submit_local.sh .